﻿namespace Capa_Diseño
{
    partial class Frm_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Menu));
            PictureBox4 = new PictureBox();
            Label4 = new Label();
            PictureBox3 = new PictureBox();
            Label3 = new Label();
            PictureBox2 = new PictureBox();
            Label2 = new Label();
            PictureBox1 = new PictureBox();
            Label1 = new Label();
            Btn_Salir = new Button();
            Btn_Acerca = new Button();
            Btn_Usuarios = new Button();
            Btn_Rpt_Clientes = new Button();
            Btn_Rpt_Proveedores = new Button();
            Btn_Rpt_Medicamentos = new Button();
            Btn_Facturas = new Button();
            Btn_Medicamentos = new Button();
            Btn_Entradas = new Button();
            Btn_Proveedores = new Button();
            Btn_Clientes = new Button();
            Btn_Unidad_Medida = new Button();
            Btn_Rpt_Unidad_Medida = new Button();
            Btn_Rpt_Usuarios = new Button();
            ((System.ComponentModel.ISupportInitialize)PictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // PictureBox4
            // 
            PictureBox4.Image = (Image)resources.GetObject("PictureBox4.Image");
            PictureBox4.Location = new Point(38, 539);
            PictureBox4.Margin = new Padding(4, 3, 4, 3);
            PictureBox4.Name = "PictureBox4";
            PictureBox4.Size = new Size(290, 5);
            PictureBox4.TabIndex = 101;
            PictureBox4.TabStop = false;
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.BackColor = Color.Transparent;
            Label4.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label4.ForeColor = Color.White;
            Label4.Location = new Point(38, 515);
            Label4.Margin = new Padding(4, 0, 4, 0);
            Label4.Name = "Label4";
            Label4.Size = new Size(117, 18);
            Label4.TabIndex = 100;
            Label4.Text = "Administrador:";
            // 
            // PictureBox3
            // 
            PictureBox3.Image = (Image)resources.GetObject("PictureBox3.Image");
            PictureBox3.Location = new Point(38, 335);
            PictureBox3.Margin = new Padding(4, 3, 4, 3);
            PictureBox3.Name = "PictureBox3";
            PictureBox3.Size = new Size(290, 5);
            PictureBox3.TabIndex = 99;
            PictureBox3.TabStop = false;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.BackColor = Color.Transparent;
            Label3.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label3.ForeColor = Color.White;
            Label3.Location = new Point(38, 310);
            Label3.Margin = new Padding(4, 0, 4, 0);
            Label3.Name = "Label3";
            Label3.Size = new Size(82, 18);
            Label3.TabIndex = 98;
            Label3.Text = "Reportes:";
            // 
            // PictureBox2
            // 
            PictureBox2.Image = (Image)resources.GetObject("PictureBox2.Image");
            PictureBox2.Location = new Point(38, 218);
            PictureBox2.Margin = new Padding(4, 3, 4, 3);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(290, 5);
            PictureBox2.TabIndex = 97;
            PictureBox2.TabStop = false;
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.BackColor = Color.Transparent;
            Label2.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label2.ForeColor = Color.White;
            Label2.Location = new Point(38, 194);
            Label2.Margin = new Padding(4, 0, 4, 0);
            Label2.Name = "Label2";
            Label2.Size = new Size(115, 18);
            Label2.TabIndex = 96;
            Label2.Text = "Trasacciones:";
            // 
            // PictureBox1
            // 
            PictureBox1.Image = (Image)resources.GetObject("PictureBox1.Image");
            PictureBox1.Location = new Point(38, 35);
            PictureBox1.Margin = new Padding(4, 3, 4, 3);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(290, 5);
            PictureBox1.TabIndex = 95;
            PictureBox1.TabStop = false;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.BackColor = Color.Transparent;
            Label1.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label1.ForeColor = Color.White;
            Label1.Location = new Point(38, 10);
            Label1.Margin = new Padding(4, 0, 4, 0);
            Label1.Name = "Label1";
            Label1.Size = new Size(82, 18);
            Label1.TabIndex = 94;
            Label1.Text = "Registrar:";
            // 
            // Btn_Salir
            // 
            Btn_Salir.BackColor = Color.Transparent;
            Btn_Salir.FlatAppearance.BorderSize = 0;
            Btn_Salir.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Salir.FlatStyle = FlatStyle.Flat;
            Btn_Salir.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Salir.ForeColor = SystemColors.ButtonHighlight;
            Btn_Salir.Image = (Image)resources.GetObject("Btn_Salir.Image");
            Btn_Salir.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Salir.Location = new Point(38, 631);
            Btn_Salir.Margin = new Padding(4, 3, 4, 3);
            Btn_Salir.Name = "Btn_Salir";
            Btn_Salir.Size = new Size(290, 30);
            Btn_Salir.TabIndex = 91;
            Btn_Salir.Text = "       Salir del Sistema      ";
            Btn_Salir.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Salir.UseVisualStyleBackColor = false;
            Btn_Salir.Click += Btn_Salir_Click;
            // 
            // Btn_Acerca
            // 
            Btn_Acerca.BackColor = Color.Transparent;
            Btn_Acerca.FlatAppearance.BorderSize = 0;
            Btn_Acerca.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Acerca.FlatStyle = FlatStyle.Flat;
            Btn_Acerca.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Acerca.ForeColor = SystemColors.ButtonHighlight;
            Btn_Acerca.Image = (Image)resources.GetObject("Btn_Acerca.Image");
            Btn_Acerca.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Acerca.Location = new Point(38, 592);
            Btn_Acerca.Margin = new Padding(4, 3, 4, 3);
            Btn_Acerca.Name = "Btn_Acerca";
            Btn_Acerca.Size = new Size(290, 30);
            Btn_Acerca.TabIndex = 92;
            Btn_Acerca.Text = "       Acerca del Sistema   ";
            Btn_Acerca.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Acerca.UseVisualStyleBackColor = false;
            Btn_Acerca.Click += Btn_Acerca_Click;
            // 
            // Btn_Usuarios
            // 
            Btn_Usuarios.BackColor = Color.Transparent;
            Btn_Usuarios.FlatAppearance.BorderSize = 0;
            Btn_Usuarios.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Usuarios.FlatStyle = FlatStyle.Flat;
            Btn_Usuarios.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Usuarios.ForeColor = SystemColors.ButtonHighlight;
            Btn_Usuarios.Image = (Image)resources.GetObject("Btn_Usuarios.Image");
            Btn_Usuarios.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Usuarios.Location = new Point(38, 555);
            Btn_Usuarios.Margin = new Padding(4, 3, 4, 3);
            Btn_Usuarios.Name = "Btn_Usuarios";
            Btn_Usuarios.Size = new Size(290, 30);
            Btn_Usuarios.TabIndex = 93;
            Btn_Usuarios.Text = "       Registrar Usuarios    ";
            Btn_Usuarios.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Usuarios.UseVisualStyleBackColor = false;
            Btn_Usuarios.Click += Btn_Usuarios_Click;
            // 
            // Btn_Rpt_Clientes
            // 
            Btn_Rpt_Clientes.BackColor = Color.Transparent;
            Btn_Rpt_Clientes.FlatAppearance.BorderSize = 0;
            Btn_Rpt_Clientes.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Rpt_Clientes.FlatStyle = FlatStyle.Flat;
            Btn_Rpt_Clientes.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Rpt_Clientes.ForeColor = SystemColors.ButtonHighlight;
            Btn_Rpt_Clientes.Image = (Image)resources.GetObject("Btn_Rpt_Clientes.Image");
            Btn_Rpt_Clientes.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Clientes.Location = new Point(42, 376);
            Btn_Rpt_Clientes.Margin = new Padding(4, 3, 4, 3);
            Btn_Rpt_Clientes.Name = "Btn_Rpt_Clientes";
            Btn_Rpt_Clientes.Size = new Size(287, 30);
            Btn_Rpt_Clientes.TabIndex = 90;
            Btn_Rpt_Clientes.Text = "       Listado de Clientes";
            Btn_Rpt_Clientes.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Clientes.UseVisualStyleBackColor = false;
            Btn_Rpt_Clientes.Click += Btn_Rpt_Clientes_Click;
            // 
            // Btn_Rpt_Proveedores
            // 
            Btn_Rpt_Proveedores.BackColor = Color.Transparent;
            Btn_Rpt_Proveedores.FlatAppearance.BorderSize = 0;
            Btn_Rpt_Proveedores.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Rpt_Proveedores.FlatStyle = FlatStyle.Flat;
            Btn_Rpt_Proveedores.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Rpt_Proveedores.ForeColor = SystemColors.ButtonHighlight;
            Btn_Rpt_Proveedores.Image = (Image)resources.GetObject("Btn_Rpt_Proveedores.Image");
            Btn_Rpt_Proveedores.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Proveedores.Location = new Point(42, 407);
            Btn_Rpt_Proveedores.Margin = new Padding(4, 3, 4, 3);
            Btn_Rpt_Proveedores.Name = "Btn_Rpt_Proveedores";
            Btn_Rpt_Proveedores.Size = new Size(287, 30);
            Btn_Rpt_Proveedores.TabIndex = 88;
            Btn_Rpt_Proveedores.Text = "       Listado de Proveedores";
            Btn_Rpt_Proveedores.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Proveedores.UseVisualStyleBackColor = false;
            Btn_Rpt_Proveedores.Click += Btn_Rpt_Proveedores_Click;
            // 
            // Btn_Rpt_Medicamentos
            // 
            Btn_Rpt_Medicamentos.BackColor = Color.Transparent;
            Btn_Rpt_Medicamentos.FlatAppearance.BorderSize = 0;
            Btn_Rpt_Medicamentos.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Rpt_Medicamentos.FlatStyle = FlatStyle.Flat;
            Btn_Rpt_Medicamentos.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Rpt_Medicamentos.ForeColor = SystemColors.ButtonHighlight;
            Btn_Rpt_Medicamentos.Image = (Image)resources.GetObject("Btn_Rpt_Medicamentos.Image");
            Btn_Rpt_Medicamentos.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Medicamentos.Location = new Point(42, 443);
            Btn_Rpt_Medicamentos.Margin = new Padding(4, 3, 4, 3);
            Btn_Rpt_Medicamentos.Name = "Btn_Rpt_Medicamentos";
            Btn_Rpt_Medicamentos.Size = new Size(287, 30);
            Btn_Rpt_Medicamentos.TabIndex = 86;
            Btn_Rpt_Medicamentos.Text = "       Listado de Medicamentos";
            Btn_Rpt_Medicamentos.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Medicamentos.UseVisualStyleBackColor = false;
            Btn_Rpt_Medicamentos.Click += Btn_Rpt_Medicamentos_Click;
            // 
            // Btn_Facturas
            // 
            Btn_Facturas.BackColor = Color.Transparent;
            Btn_Facturas.FlatAppearance.BorderSize = 0;
            Btn_Facturas.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Facturas.FlatStyle = FlatStyle.Flat;
            Btn_Facturas.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Facturas.ForeColor = SystemColors.ButtonHighlight;
            Btn_Facturas.Image = (Image)resources.GetObject("Btn_Facturas.Image");
            Btn_Facturas.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Facturas.Location = new Point(42, 268);
            Btn_Facturas.Margin = new Padding(4, 3, 4, 3);
            Btn_Facturas.Name = "Btn_Facturas";
            Btn_Facturas.Size = new Size(287, 30);
            Btn_Facturas.TabIndex = 83;
            Btn_Facturas.Text = "       Facturar";
            Btn_Facturas.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Facturas.UseVisualStyleBackColor = false;
            Btn_Facturas.Click += Btn_Facturas_Click;
            // 
            // Btn_Medicamentos
            // 
            Btn_Medicamentos.BackColor = Color.Transparent;
            Btn_Medicamentos.FlatAppearance.BorderSize = 0;
            Btn_Medicamentos.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Medicamentos.FlatStyle = FlatStyle.Flat;
            Btn_Medicamentos.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Medicamentos.ForeColor = SystemColors.ButtonHighlight;
            Btn_Medicamentos.Image = (Image)resources.GetObject("Btn_Medicamentos.Image");
            Btn_Medicamentos.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Medicamentos.Location = new Point(38, 156);
            Btn_Medicamentos.Margin = new Padding(4, 3, 4, 3);
            Btn_Medicamentos.Name = "Btn_Medicamentos";
            Btn_Medicamentos.Size = new Size(290, 30);
            Btn_Medicamentos.TabIndex = 85;
            Btn_Medicamentos.Text = "       Registrar Médicamentos";
            Btn_Medicamentos.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Medicamentos.UseVisualStyleBackColor = false;
            Btn_Medicamentos.Click += Btn_Medicamentos_Click;
            // 
            // Btn_Entradas
            // 
            Btn_Entradas.BackColor = Color.Transparent;
            Btn_Entradas.FlatAppearance.BorderSize = 0;
            Btn_Entradas.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Entradas.FlatStyle = FlatStyle.Flat;
            Btn_Entradas.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Entradas.ForeColor = SystemColors.ButtonHighlight;
            Btn_Entradas.Image = (Image)resources.GetObject("Btn_Entradas.Image");
            Btn_Entradas.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Entradas.Location = new Point(42, 231);
            Btn_Entradas.Margin = new Padding(4, 3, 4, 3);
            Btn_Entradas.Name = "Btn_Entradas";
            Btn_Entradas.Size = new Size(287, 30);
            Btn_Entradas.TabIndex = 81;
            Btn_Entradas.Text = "       Compras";
            Btn_Entradas.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Entradas.UseVisualStyleBackColor = false;
            Btn_Entradas.Click += Btn_Entradas_Click;
            // 
            // Btn_Proveedores
            // 
            Btn_Proveedores.BackColor = Color.Transparent;
            Btn_Proveedores.FlatAppearance.BorderSize = 0;
            Btn_Proveedores.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Proveedores.FlatStyle = FlatStyle.Flat;
            Btn_Proveedores.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Proveedores.ForeColor = SystemColors.ButtonHighlight;
            Btn_Proveedores.Image = (Image)resources.GetObject("Btn_Proveedores.Image");
            Btn_Proveedores.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Proveedores.Location = new Point(38, 118);
            Btn_Proveedores.Margin = new Padding(4, 3, 4, 3);
            Btn_Proveedores.Name = "Btn_Proveedores";
            Btn_Proveedores.Size = new Size(290, 30);
            Btn_Proveedores.TabIndex = 84;
            Btn_Proveedores.Text = "       Registrar Proveedores";
            Btn_Proveedores.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Proveedores.UseVisualStyleBackColor = false;
            Btn_Proveedores.Click += Btn_Proveedores_Click;
            // 
            // Btn_Clientes
            // 
            Btn_Clientes.BackColor = Color.Transparent;
            Btn_Clientes.FlatAppearance.BorderSize = 0;
            Btn_Clientes.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Clientes.FlatStyle = FlatStyle.Flat;
            Btn_Clientes.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Clientes.ForeColor = SystemColors.ButtonHighlight;
            Btn_Clientes.Image = (Image)resources.GetObject("Btn_Clientes.Image");
            Btn_Clientes.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Clientes.Location = new Point(38, 82);
            Btn_Clientes.Margin = new Padding(4, 3, 4, 3);
            Btn_Clientes.Name = "Btn_Clientes";
            Btn_Clientes.Size = new Size(290, 30);
            Btn_Clientes.TabIndex = 82;
            Btn_Clientes.Text = "       Registrar Clientes";
            Btn_Clientes.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Clientes.UseVisualStyleBackColor = false;
            Btn_Clientes.Click += Btn_Clientes_Click;
            // 
            // Btn_Unidad_Medida
            // 
            Btn_Unidad_Medida.BackColor = Color.Transparent;
            Btn_Unidad_Medida.FlatAppearance.BorderSize = 0;
            Btn_Unidad_Medida.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Unidad_Medida.FlatStyle = FlatStyle.Flat;
            Btn_Unidad_Medida.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Unidad_Medida.ForeColor = SystemColors.ButtonHighlight;
            Btn_Unidad_Medida.Image = (Image)resources.GetObject("Btn_Unidad_Medida.Image");
            Btn_Unidad_Medida.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Unidad_Medida.Location = new Point(38, 47);
            Btn_Unidad_Medida.Margin = new Padding(4, 3, 4, 3);
            Btn_Unidad_Medida.Name = "Btn_Unidad_Medida";
            Btn_Unidad_Medida.Size = new Size(290, 30);
            Btn_Unidad_Medida.TabIndex = 102;
            Btn_Unidad_Medida.Text = "       Registrar Unidad de Medidas";
            Btn_Unidad_Medida.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Unidad_Medida.UseVisualStyleBackColor = false;
            Btn_Unidad_Medida.Click += Btn_Unidad_Medida_Click;
            // 
            // Btn_Rpt_Unidad_Medida
            // 
            Btn_Rpt_Unidad_Medida.BackColor = Color.Transparent;
            Btn_Rpt_Unidad_Medida.FlatAppearance.BorderSize = 0;
            Btn_Rpt_Unidad_Medida.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Rpt_Unidad_Medida.FlatStyle = FlatStyle.Flat;
            Btn_Rpt_Unidad_Medida.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Rpt_Unidad_Medida.ForeColor = SystemColors.ButtonHighlight;
            Btn_Rpt_Unidad_Medida.Image = (Image)resources.GetObject("Btn_Rpt_Unidad_Medida.Image");
            Btn_Rpt_Unidad_Medida.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Unidad_Medida.Location = new Point(40, 344);
            Btn_Rpt_Unidad_Medida.Margin = new Padding(4, 3, 4, 3);
            Btn_Rpt_Unidad_Medida.Name = "Btn_Rpt_Unidad_Medida";
            Btn_Rpt_Unidad_Medida.Size = new Size(287, 30);
            Btn_Rpt_Unidad_Medida.TabIndex = 103;
            Btn_Rpt_Unidad_Medida.Text = "       Listado de Unidad de Medida";
            Btn_Rpt_Unidad_Medida.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Unidad_Medida.UseVisualStyleBackColor = false;
            Btn_Rpt_Unidad_Medida.Click += Btn_Rpt_Unidad_Medida_Click;
            // 
            // Btn_Rpt_Usuarios
            // 
            Btn_Rpt_Usuarios.BackColor = Color.Transparent;
            Btn_Rpt_Usuarios.FlatAppearance.BorderSize = 0;
            Btn_Rpt_Usuarios.FlatAppearance.MouseOverBackColor = Color.LightSteelBlue;
            Btn_Rpt_Usuarios.FlatStyle = FlatStyle.Flat;
            Btn_Rpt_Usuarios.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Rpt_Usuarios.ForeColor = SystemColors.ButtonHighlight;
            Btn_Rpt_Usuarios.Image = (Image)resources.GetObject("Btn_Rpt_Usuarios.Image");
            Btn_Rpt_Usuarios.ImageAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Usuarios.Location = new Point(42, 475);
            Btn_Rpt_Usuarios.Margin = new Padding(4, 3, 4, 3);
            Btn_Rpt_Usuarios.Name = "Btn_Rpt_Usuarios";
            Btn_Rpt_Usuarios.Size = new Size(287, 30);
            Btn_Rpt_Usuarios.TabIndex = 104;
            Btn_Rpt_Usuarios.Text = "       Listado de Usuarios";
            Btn_Rpt_Usuarios.TextAlign = ContentAlignment.MiddleLeft;
            Btn_Rpt_Usuarios.UseVisualStyleBackColor = false;
            Btn_Rpt_Usuarios.Click += Btn_Rpt_Usuarios_Click;
            // 
            // Frm_Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 128, 128);
            ClientSize = new Size(368, 712);
            Controls.Add(Btn_Rpt_Usuarios);
            Controls.Add(Btn_Rpt_Unidad_Medida);
            Controls.Add(Btn_Unidad_Medida);
            Controls.Add(PictureBox4);
            Controls.Add(Label4);
            Controls.Add(PictureBox3);
            Controls.Add(Label3);
            Controls.Add(PictureBox2);
            Controls.Add(Label2);
            Controls.Add(PictureBox1);
            Controls.Add(Label1);
            Controls.Add(Btn_Salir);
            Controls.Add(Btn_Acerca);
            Controls.Add(Btn_Usuarios);
            Controls.Add(Btn_Rpt_Clientes);
            Controls.Add(Btn_Rpt_Proveedores);
            Controls.Add(Btn_Rpt_Medicamentos);
            Controls.Add(Btn_Facturas);
            Controls.Add(Btn_Medicamentos);
            Controls.Add(Btn_Entradas);
            Controls.Add(Btn_Proveedores);
            Controls.Add(Btn_Clientes);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Frm_Menu";
            Text = "Frm_Menu";
            Load += Frm_Menu_Load;
            ((System.ComponentModel.ISupportInitialize)PictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button Btn_Salir;
        internal System.Windows.Forms.Button Btn_Acerca;
        internal System.Windows.Forms.Button Btn_Usuarios;
        internal System.Windows.Forms.Button Btn_Rpt_Clientes;
        internal System.Windows.Forms.Button Btn_Rpt_Proveedores;
        internal System.Windows.Forms.Button Btn_Rpt_Medicamentos;
        internal System.Windows.Forms.Button Btn_Facturas;
        internal System.Windows.Forms.Button Btn_Medicamentos;
        internal System.Windows.Forms.Button Btn_Entradas;
        internal System.Windows.Forms.Button Btn_Proveedores;
        internal System.Windows.Forms.Button Btn_Clientes;
        internal System.Windows.Forms.Button Btn_Unidad_Medida;
        internal System.Windows.Forms.Button Btn_Rpt_Unidad_Medida;
        internal System.Windows.Forms.Button Btn_Rpt_Usuarios;
    }
}