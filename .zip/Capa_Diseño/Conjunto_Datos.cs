﻿namespace Capa_Diseño
{
}

namespace Capa_Diseño
{


    public partial class Conjunto_Datos
    {
    }
}
namespace Capa_Diseño {
    
    
    public partial class Conjunto_Datos {
    }
}
