﻿//using System;
//using System.Linq;               // Para OfType<T>()
//using System.Windows.Forms;
//using System.Drawing;

//namespace Capa_Diseño
//{
//    public partial class Frm_Menu : Form
//    {
//        // Mapea aquí los códigos de tus reportes (ajústalos si en tu proyecto son otros)
//        private const int REP_UNIDAD_MEDIDA = 1;
//        private const int REP_CLIENTES = 2;
//        private const int REP_PROVEEDORES = 3; // igual que tu ejemplo previo
//        private const int REP_MEDICAMENTOS = 4; // igual que tu ejemplo previo
//        private const int REP_USUARIOS = 5;

//        public Frm_Menu()
//        {
//            InitializeComponent();

//            // El formulario actuará como contenedor MDI y abre maximizado
//            IsMdiContainer = true;
//            WindowState = FormWindowState.Maximized;

//            // Renderer con tema similar a tu UI (fondo rosa + hover LightSteelBlue)
//            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
//            menuStrip1.Renderer = new ToolStripProfessionalRenderer(new RosaColorTable());
//        }

//        // -------- Utilidades --------
//        // Abre (o enfoca si ya existe) un formulario hijo MDI
//        private void OpenChild<T>() where T : Form, new()
//        {
//            var abierto = MdiChildren.OfType<T>().FirstOrDefault();
//            if (abierto != null)
//            {
//                abierto.WindowState = FormWindowState.Maximized;
//                abierto.Activate();
//                return;
//            }

//            var frm = new T
//            {
//                MdiParent = this,
//                WindowState = FormWindowState.Maximized
//            };
//            frm.Show();
//        }

//        // Abre un reporte en el visor modal, con confirmación
//        private void AbrirReporte(int codigoReporte)
//        {
//            var resp = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA,
//                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question);
//            if (resp == DialogResult.No) return;

//            Program.xReporte = codigoReporte;

//            using (var visor = new Frm_Visualizador())
//                visor.ShowDialog(this);
//        }

//        // -------- Handlers: REGISTRAR (MDI) --------
//        private void menuRegistrarUMedida_Click(object s, EventArgs e) => OpenChild<Frm_Unidad_Medida>();   // o Frm_Unidad_Medida
//        private void menuRegistrarClientes_Click(object s, EventArgs e) => OpenChild<Frm_Clientes>();
//        private void menuRegistrarProveedores_Click(object s, EventArgs e) => OpenChild<Frm_Proveedores>();
//        //private void menuRegistrarMedicamentos_Click(object s, EventArgs e) => OpenChild<Frm_Medicamentos>();

//        // -------- Handlers: TRANSACCIONES (MDI) --------
//        private void menuTransCompras_Click(object s, EventArgs e) => OpenChild<Frm_Entrada>();   // Compras
//        private void menuTransFacturar_Click(object s, EventArgs e) => OpenChild<Frm_Factura>();   // Facturar

//        // -------- Handlers: REPORTES (Modal) --------
//        private void menuRptUMedida_Click(object s, EventArgs e) => AbrirReporte(REP_UNIDAD_MEDIDA);
//        private void menuRptClientes_Click(object s, EventArgs e) => AbrirReporte(REP_CLIENTES);
//        private void menuRptProveedores_Click(object s, EventArgs e) => AbrirReporte(REP_PROVEEDORES);   // como tu botón anterior
//        private void menuRptMedicamentos_Click(object s, EventArgs e) => AbrirReporte(REP_MEDICAMENTOS);  // como tu botón anterior
//        private void menuRptUsuarios_Click(object s, EventArgs e) => AbrirReporte(REP_USUARIOS);

//        // -------- Handlers: ADMINISTRADOR --------
//        private void menuAdminUsuarios_Click(object s, EventArgs e) => OpenChild<Frm_Usuarios>();
//        private void menuAdminAcerca_Click(object s, EventArgs e)
//            => MessageBox.Show("Sistema de Farmacia\nVersión 1.0", "Acerca de", MessageBoxButtons.OK, MessageBoxIcon.Information);
//        private void menuAdminSalir_Click(object s, EventArgs e) => Close();
//    }

//    // Tema de colores para el MenuStrip (rosa + hover LightSteelBlue)
//    internal class RosaColorTable : ProfessionalColorTable
//    {
//        private static readonly Color RosaSuave = Color.FromArgb(255, 128, 128); // mismo fondo de tu form original:contentReference[oaicite:1]{index=1}
//        private static readonly Color Hover = Color.LightSteelBlue;               // hover de tus botones originales:contentReference[oaicite:2]{index=2}
//        private static readonly Color Borde = Color.FromArgb(200, 90, 90);

//        public override Color MenuStripGradientBegin => RosaSuave;
//        public override Color MenuStripGradientEnd => RosaSuave;
//        public override Color ToolStripDropDownBackground => Color.FromArgb(255, 220, 220);
//        public override Color ImageMarginGradientBegin => ToolStripDropDownBackground;
//        public override Color ImageMarginGradientMiddle => ToolStripDropDownBackground;
//        public override Color ImageMarginGradientEnd => ToolStripDropDownBackground;
//        public override Color MenuItemSelected => Hover;
//        public override Color MenuItemBorder => Borde;
//        public override Color MenuItemPressedGradientBegin => Color.FromArgb(255, 200, 200);
//        public override Color MenuItemPressedGradientEnd => Color.FromArgb(255, 200, 200);
//    }
//}



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capa_Diseño
{
    public partial class Frm_Menu : Form
    {
        public Frm_Menu()
        {
            InitializeComponent();
        }

        private void Frm_Menu_Load(object sender, EventArgs e)
        {
            this.Location = new Point(0, 0);

        }

        private void Btn_Clientes_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Clientes oForm = new Frm_Clientes();
            oForm.ShowDialog();

        }

        private void Btn_Unidad_Medida_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Unidad_Medida oForm = new Frm_Unidad_Medida();
            oForm.ShowDialog();
        }

        private void Btn_Salir_Click(object sender, EventArgs e)
        {
            //Fin de la Aplicacion
            Program.xMensaje = MessageBox.Show("¿DESE SALIR DEL SISTEMA?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.Yes)
                Application.Exit();

        }

        private void Btn_Medicamentos_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Productos oForm = new Frm_Productos();
            oForm.ShowDialog();
        }

        private void Btn_Proveedores_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Proveedores oForm = new Frm_Proveedores();
            oForm.ShowDialog();
        }

        private void Btn_Usuarios_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (Program.Rol_Quien != "ADMINISTRADOR")
            {
                MessageBox.Show("Esta ventana es solo para la Cuenta de Administrador!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }


            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Usuarios oForm = new Frm_Usuarios();
            oForm.ShowDialog();
        }

        private void Btn_Rpt_Unidad_Medida_Click(object sender, EventArgs e)
        {
            // Verificando Si desea Imprimir
            Program.xMensaje = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.No)
            { return; }

            Program.xReporte = 1;

            Frm_Visualizador xForm = new Frm_Visualizador();
            xForm.ShowDialog();
        }

        private void Btn_Rpt_Clientes_Click(object sender, EventArgs e)
        {
            // Verificando Si desea Imprimir
            Program.xMensaje = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.No)
            { return; }

            Program.xReporte = 2;

            Frm_Visualizador xForm = new Frm_Visualizador();
            xForm.ShowDialog();
        }

        private void Btn_Rpt_Proveedores_Click(object sender, EventArgs e)
        {
            // Verificando Si desea Imprimir
            Program.xMensaje = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.No)
            { return; }

            Program.xReporte = 3;

            Frm_Visualizador xForm = new Frm_Visualizador();
            xForm.ShowDialog();
        }

        private void Btn_Rpt_Medicamentos_Click(object sender, EventArgs e)
        {
            // Verificando Si desea Imprimir
            Program.xMensaje = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.No)
            { return; }

            Program.xReporte = 4;

            Frm_Visualizador xForm = new Frm_Visualizador();
            xForm.ShowDialog();
        }

        private void Btn_Rpt_Usuarios_Click(object sender, EventArgs e)
        {
            // Verificando Si desea Imprimir
            Program.xMensaje = MessageBox.Show("¿Desea Imprimir los Registros?", Program.SISTEMA, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Program.xMensaje == DialogResult.No)
            { return; }

            Program.xReporte = 5;

            Frm_Visualizador xForm = new Frm_Visualizador();
            xForm.ShowDialog();
        }

        private void Btn_Acerca_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Acerca oForm = new Frm_Acerca();
            oForm.ShowDialog();
        }

        private void Btn_Entradas_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Entrada oForm = new Frm_Entrada();
            oForm.ShowDialog();
        }

        private void Btn_Facturas_Click(object sender, EventArgs e)
        {
            //Para ver si tiene despliega la opcion en caso de estar cerrado
            if (Program.xAcceso != 0)
            {
                MessageBox.Show("Debe de Cerrar el Formulario que está abierto!!!", Program.SISTEMA, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Llamada del Formulario
            Program.Val_Ban = 0;

            Frm_Factura oForm = new Frm_Factura();
            oForm.ShowDialog();
        }
    }
}
